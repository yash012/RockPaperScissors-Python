import random
Cchoice=["Rock","Paper","Scissor"]
print("Instructions : ")
print("    Please first enter no. of Rounds you want")
print("    Every Draw match will give +1 point to each player")
print("    Please Enter no. written before your choice")
print("    If you Enter any invalid choice then that game will be terminated")
print("    If you want to play again then enter yes")
while True:
    print("Rock Paper Scissor Game: ")
    youwin, computerwin = 0, 0
    turns=int(input("Best out of : "))
    for i in range(turns):
        print("Round",i+1,"Start:")
        print("Please select any one option:")
        print("1.Rock","2.Paper","3.Scissor",sep="\n")
        Yourchoice=int(input())
        if Yourchoice==1:
            print("You select Rock")
            Yourchoice="Rock"
        elif Yourchoice==2:
            print("You select Paper")
            Yourchoice="Paper"
        elif Yourchoice==3:
            print("You select Scissor")
            Yourchoice="Scissor"
        else:
            print("Invalid Choice")
            break
        Computerchoice=random.choice(Cchoice)
        print("Computer select:",Computerchoice)
        if Yourchoice==Computerchoice:
            youwin+=1
            computerwin+=1
            print("This Round is Drawn:")
        elif (Yourchoice=="Paper" and Computerchoice=="Rock") or (Yourchoice=="Scissor" and Computerchoice=="Paper") or (Yourchoice=="Rock" and Computerchoice=="Scissor"):
            youwin+=1
            print("You win this Round")
        else:
            computerwin+=1
            print("Computer win this Round")
    if youwin>computerwin:
        print("You win the Game:")
        print("Score is:","Your score:",youwin,",Computer score:",computerwin,sep=" ")
    elif youwin<computerwin:
        print("You lose the Game, Computer win the game:")
        print("Score is:","Your score:",youwin,",Computer score:",computerwin,sep=" ")
    else:
        print("Match Drawn")
        print("Score is:","Your score:",youwin,",Computer score:",computerwin,sep=" ")
    user_choice=input("Want to play again?(Yes/Exit): ")
    if user_choice=="Yes" or user_choice=="YES" or user_choice=="yes":
        print("Welcome Back!")
        continue
    else:
        print("Thanks For Playing")
        break